<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Hisab</title>
    <!-- Favicon icon -->
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('images/favicon.png') }}">

    <!-- CSS Plugins -->
    <link href="{{ asset('vendors/jqvmap/css/jqvmap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('vendors/chartist/css/chartist.min.css') }}" rel="stylesheet">
    <link href="{{ asset('vendors/bootstrap-select/dist/css/bootstrap-select.min.css') }}" rel="stylesheet">
    <link href="{{ asset('vendors/owl-carousel/owl.carousel.css') }}" rel="stylesheet">

    <!-- Custom Styles -->
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<body>
<!--*******************
        Preloader start
    ********************-->
<div id="preloader">
    <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
    </div>
</div>
<!--*******************
    Preloader end
********************-->
@yield('content')

<!-- Required vendors -->
<script src="{{asset('vendors/global/global.min.js')}}"></script>
<script src="{{asset('vendors/bootstrap-select/dist/js/bootstrap-select.min.js')}}"></script>
<script src="{{asset('vendors/chart.js/Chart.bundle.min.js')}}"></script>
<script src="{{asset('vendors/owl-carousel/owl.carousel.js')}}"></script>

<!-- Chart Peity Plugin -->
<script src="{{ asset('vendors/peity/jquery.peity.min.js') }}"></script>

<!-- Apex Chart -->
<script src="{{ asset('vendors/apexchart/apexchart.js') }}"></script>

<!-- Dashboard Scripts -->
<script src="{{ asset('js/dashboard/dashboard-1.js') }}"></script>
<script src="{{ asset('js/custom.min.js') }}"></script>
<script src="{{ asset('js/deznav-init.js') }}"></script>
<script src="{{ asset('js/demo.js') }}"></script>
<script src="{{ asset('js/styleSwitcher.js') }}"></script>
</body>
</html>
