<div class="nav-header">
    <a href="{{route('dashboard')}}" class="brand-logo">
        <div class="header-left">
            <div class="dashboard_bar">
                Your Logo
            </div>
        </div>
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>
