<div class="footer">
    <div class="copyright">
        <p>Copyright © Your Company Name</p>
    </div>
</div>
