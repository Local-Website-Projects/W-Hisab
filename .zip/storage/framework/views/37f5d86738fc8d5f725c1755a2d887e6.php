<div class="nav-header">
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-logo">
        <div class="header-left">
            <div class="dashboard_bar">
                Your Logo
            </div>
        </div>
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/layouts/theme_navHeader.blade.php ENDPATH**/ ?>