<?php $__env->startSection('content'); ?>
    <div id="main-wrapper">
        <!--**********************************
            Nav header start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_navHeader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <?php echo $__env->make('layouts.theme-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Cash Book Update</a></li>
                    </ol>
                </div>

                <div class="row">
                    <div class="col-12">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mr-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                                <strong>Success!</strong> <?php echo e(session('success')); ?>

                                <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Update Entry</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('cashbook.update',$data->debit_credit_id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group">
                                            <label>Select Project*</label>
                                            <select class="form-control form-control-lg default-select" name="project_id" required>
                                                <option disabled>Select Project</option>
                                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($project->project_id); ?>" <?php echo e(($data->project_id == $project->project_id) ? 'selected':''); ?>><?php echo e($project->project_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Date*</label>
                                            <input type="date" class="form-control input-default" name="date" value="<?php echo e($data->date); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Select Supplier*</label>
                                            <select class="form-control form-control-lg default-select" name="supplier_id" required>
                                                <option disabled>Select Supplier</option>
                                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($supplier->supplier_id); ?>" <?php echo e(($data->supplier_id == $supplier->supplier_id) ? 'selected':''); ?>><?php echo e($supplier->supplier_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <?php if($data->debit): ?>
                                            <div class="form-group">
                                                <label>Amount*</label>
                                                <input type="number" class="form-control input-default" name="debit" value="<?php echo e($data->debit); ?>" required>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($data->credit): ?>
                                            <div class="form-group">
                                                <label>Amount*</label>
                                                <input type="number" class="form-control input-default" name="credit" value="<?php echo e($data->credit); ?>" required>
                                            </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label>Note*</label>
                                            <textarea class="form-control" rows="4" id="comment" name="note" required><?php echo e($data->note); ?></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-rounded btn-outline-primary">Save</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/debitCredit/edit.blade.php ENDPATH**/ ?>