<?php $__env->startSection('content'); ?>
    <div id="main-wrapper">
        <!--**********************************
            Nav header start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_navHeader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Nav header end
        ***********************************-->


        <!--**********************************
            Header start
        ***********************************-->
        <?php echo $__env->make('layouts.theme-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row sp-sm-15">
                    <div class="col-xl-3 col-xxl-4 col-md-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-black mb-0">Cash In Hand</p>
                                <span class="fs-28 text-black font-w600 d-block"><?php echo e($cashOnHand); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-xxl-4 col-md-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-black mb-0">Today Deposit</p>
                                <span class="fs-28 text-black font-w600 d-block"><?php echo e($todayDeposit); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-xxl-4 col-md-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-black mb-0">Today Expense</p>
                                <span class="fs-28 text-black font-w600 d-block"><?php echo e($todayExpense); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-xxl-4 col-md-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-black mb-0">Total Suppliers</p>
                                <span class="fs-28 text-black font-w600 d-block"><?php echo e($suppliers); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Today Cash Book</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive-md table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Project Name</th>
                                            <th>Supplier Name</th>
                                            <th>Product Name</th>
                                            <th>Note</th>
                                            <th>Credit</th>
                                            <th>Debit</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $cashbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($cashbook->project->project_name); ?></td>
                                                <td><?php echo e(optional($cashbook->supplier)->supplier_name ?? 'N/A'); ?></td>
                                                <td><?php echo e(optional($cashbook->product)->product_name ?? 'N/A'); ?></td>
                                                <td><?php echo e($cashbook->note); ?></td>
                                                <td><?php echo e($cashbook->credit); ?></td>
                                                <td><?php echo e($cashbook->debit); ?></td>
                                                <td>
                                                    <div class="d-flex">
                                                        <a href="<?php echo e(route('cashbook.edit',$cashbook->debit_credit_id)); ?>" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></a>
                                                        <form action="<?php echo e(route('cashbook.destroy', $cashbook->debit_credit_id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this data?');" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger shadow btn-xs sharp mr-1"><i class="fa fa-trash"></i></button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                    <div class="d-flex justify-content-center mt-4">
                                        <?php echo e($cashbooks->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-md-3 col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="media pb-2 border-bottom align-items-center">
                                        <div class="media-body">
                                            <h4 class="fs-20"><?php echo e($result['project_name']); ?></h4>
                                        </div>
                                    </div>
                                    <div class="d-flex mb-3 mt-3">
											<span class="text-black mr-auto font-w500">
											Total Credit: <?php echo e($result['total_credit']); ?><br/>Total Debit: <?php echo e($result['total_debit']); ?>   </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/dashboard.blade.php ENDPATH**/ ?>