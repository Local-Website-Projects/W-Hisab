<!DOCTYPE html>
<html>
<head>
    <title>Projectwise Cashbook Report</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
        }
        *{
            font-size:12px !important;
        }
    </style>
</head>
<body class="p-4">

<div class="no-print text-end mb-3">
    <button onclick="window.print()" class="btn btn-primary">Print Report</button>
</div>

<h2 class="text-center mb-4" style="font-size: 32px !important;">Project: <?php echo e($projectName); ?></h2>

<table class="table table-bordered mt-3">
    <thead class="table-dark">
    <tr>
        <th>#</th>
        <th>Purchaser/Supplier Name</th>
        <th>Credit (Payable)</th>
        <th>Debit (Receivable)</th>
    </tr>
    </thead>
    <tbody>
    <?php
        $total_debit = 0;
        $total_credit = 0;
    ?>

    <?php $__empty_1 = true; $__currentLoopData = $balance_sheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($index + 1); ?></td>

            
            <td><?php echo e($row['supplier_name']); ?></td>

            <td><?php echo e(formatBDT($row['payable'], 0)); ?></td>
            <td><?php echo e(formatBDT($row['receivable'], 0)); ?></td>

            <?php
                $total_credit += $row['payable'];     // credit column → payable
                $total_debit  += $row['receivable'];  // debit column → receivable
            ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4" class="text-center">No data found for selected date range.</td>
        </tr>
    <?php endif; ?>
    <tr>
        <?php if($total_debit > $total_credit): ?>
            <?php $profit = $total_debit - $total_credit; ?>
            <td></td>
            <td>Cash In Hand</td>
            <td><?php echo e(formatBDT($profit, 0)); ?></td>
            <td></td>
            <?php $total_credit += $profit; ?>

        <?php elseif($total_debit < $total_credit): ?>
            <?php $loss = $total_credit - $total_debit; ?>
            <td></td>
            <td>Cash In Hand</td>
            <td></td>
            <td><?php echo e(formatBDT($loss, 0)); ?></td>
            <?php $total_debit += $loss; ?>

        <?php else: ?>
            <td></td>
            <td>Profit/Loss</td>
            <td>0</td>
            <td>0</td>
        <?php endif; ?>
    </tr>
    <tr class="fw-bold">
        <td colspan="2" class="text-end">Total:</td>
        <td><?php echo e(formatBDT($total_credit, 0)); ?></td>
        <td><?php echo e(formatBDT($total_debit, 0)); ?></td>
    </tr>
    </tbody>
</table>


<div class="no-print text-end mt-3">
    <button onclick="window.print()" class="btn btn-primary">Print Report</button>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/reports/projectwise-report.blade.php ENDPATH**/ ?>