<!DOCTYPE html>
<html>
<head>
    <title>Projectwise Cashbook Report</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
        }
        *{
            font-size:12px !important;
        }
    </style>
</head>
<body class="p-4">

<div class="no-print text-end mb-3">
    <button onclick="window.print()" class="btn btn-primary">Print Report</button>
</div>

<h1 class="text-center mb-4" style="font-size: 20px !important;">Supplier: <?php echo e($name->supplier_name); ?></h1>

<table class="table table-bordered mt-3">
    <thead>
    <tr class="text-center">
        <th colspan="6">Purchase Order</th>
        <th colspan="4">Paid Amounts</th>
    </tr>
    <tr>
        <th>Sl No</th>
        <th>Date</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Unit Price</th>
        <th>Total Price</th>

        <th>Sl No</th>
        <th>Date</th>
        <th>Note</th>
        <th>Amount</th>
    </tr>
    </thead>

    <tbody>
    <?php
        $purchases = $supplier->purchases;
        $payments = $supplier->payments;

        $maxRows = max($purchases->count(), $payments->count());
    ?>

    <?php for($i = 0; $i < $maxRows; $i++): ?>
        <tr>
            
            <?php if(isset($purchases[$i])): ?>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($purchases[$i]->created_at)->format('d M, Y')); ?></td>
                <td><?php echo e($purchases[$i]->product->product_name ?? 'N/A'); ?></td>
                <td><?php echo e($purchases[$i]->quantity); ?> <?php echo e($purchases[$i]->unit); ?></td>
                <td><?php echo e(number_format($purchases[$i]->unit_price, 2)); ?></td>
                <td><?php echo e(number_format($purchases[$i]->total_price, 2)); ?></td>
            <?php else: ?>
                <td colspan="6" class="text-center">—</td>
            <?php endif; ?>


            
            <?php if(isset($payments[$i])): ?>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($payments[$i]->date)->format('d M, Y')); ?></td>
                <td><?php echo e($payments[$i]->note); ?></td>
                <td><?php echo e(number_format($payments[$i]->debit, 2)); ?></td>
            <?php else: ?>
                <td colspan="4" class="text-center">—</td>
            <?php endif; ?>
        </tr>
    <?php endfor; ?>


    
    <tr style="font-weight: bold; background:#e9ecef;">
        <td colspan="5" class="text-right">
            Total Purchases:
        </td>
        <td class="text-left">
            <?php echo e(number_format($purchases->sum('total_price'), 2)); ?>

        </td>
        <td colspan="3" class="text-right">
            Total Paid:
        </td>
        <td class="text-left">
            <?php echo e(number_format($payments->sum('debit'), 2)); ?>

        </td>
    </tr>

    
    <?php
        $totalPaid = $payments->sum('debit');
        $totalPurchase = $purchases->sum('total_price');
    ?>
    <tr style="font-weight: bold; background:#d6ffd6;">
        <td colspan="10" class="text-center">
            <?php echo e($totalPaid >= $totalPurchase ? 'Advance Payment to Supplier: ' : 'Payable to Supplier: '); ?> <?php echo e(number_format(abs($totalPaid - $totalPurchase), 2)); ?>

        </td>
    </tr>
    </tbody>
</table>

<div class="no-print text-end mt-3">
    <button onclick="window.print()" class="btn btn-primary">Print Report</button>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/reports/supplierwise-report.blade.php ENDPATH**/ ?>