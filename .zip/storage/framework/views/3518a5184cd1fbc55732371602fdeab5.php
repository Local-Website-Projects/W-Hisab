<!DOCTYPE html>
<html>
<head>
    <title>Purchaser Report</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
        }
        *{
            font-size:12px !important;
        }
    </style>
</head>
<body class="p-4">

<div class="no-print text-end mb-3">
    <button onclick="window.print()" class="btn btn-primary">Print Report</button>
</div>

<h1 class="text-center mb-4" style="font-size: 20px !important;">Purchaser: <?php echo e($name->supplier_name); ?></h1>

<table class="table table-bordered mt-3">
    <thead>
    <tr class="text-center">
        <th colspan="5">Flat Purchase</th>
        <th colspan="4">Paid Amounts</th>
    </tr>
    <tr>
        <th>Sl No</th>
        <th>Date</th>
        <th>Project Name</th>
        <th>Note</th>
        <th>Total Price</th>

        <th>Sl No</th>
        <th>Date</th>
        <th>Note</th>
        <th>Amount</th>
    </tr>
    </thead>

    <tbody>
    <?php
        $purchases = $supplier->flatsell;
        $payments = $supplier->payments;
        $maxRows = max($purchases->count(), $payments->count());
    ?>

    <?php for($i = 0; $i < $maxRows; $i++): ?>
        <tr>
            
            <?php if(isset($purchases[$i])): ?>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($purchases[$i]->date)->format('d M, Y')); ?></td>
                <td><?php echo e($purchases[$i]->project->project_name ?? 'N/A'); ?></td>
                <td><?php echo e($purchases[$i]->note ?? '—'); ?></td>
                <td><?php echo e(number_format($purchases[$i]->total_amount, 2)); ?></td>
            <?php else: ?>
                <td colspan="5" class="text-center">—</td>
            <?php endif; ?>

            
            <?php if(isset($payments[$i])): ?>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($payments[$i]->date)->format('d M, Y')); ?></td>
                <td><?php echo e($payments[$i]->note ?? '—'); ?></td>
                <td><?php echo e(number_format($payments[$i]->credit, 2)); ?></td>
            <?php else: ?>
                <td colspan="4" class="text-center">—</td>
            <?php endif; ?>
        </tr>
    <?php endfor; ?>

    
    <?php
        $totalPurchase = $purchases->sum('total_amount');
        $totalPaid = $payments->sum('credit');
    ?>
    <tr style="font-weight: bold; background:#e9ecef;">
        <td colspan="4" class="text-right">Total Purchases:</td>
        <td><?php echo e(number_format($totalPurchase, 2)); ?></td>

        <td colspan="3" class="text-right">Total Paid:</td>
        <td><?php echo e(number_format($totalPaid, 2)); ?></td>
    </tr>

    
    <tr style="font-weight: bold; background:#d6ffd6;">
        <td colspan="9" class="text-center">
            <?php if($totalPaid >= $totalPurchase): ?>
                Payable to Purchaser: <?php echo e(number_format($totalPaid - $totalPurchase, 2)); ?>

            <?php else: ?>
                Receivable from Purchaser: <?php echo e(number_format($totalPurchase - $totalPaid, 2)); ?>

            <?php endif; ?>
        </td>
    </tr>
    </tbody>
</table>


<div class="no-print text-end mt-3">
    <button onclick="window.print()" class="btn btn-primary">Print Report</button>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/reports/purchaser-report.blade.php ENDPATH**/ ?>