<div class="footer">
    <div class="copyright">
        <p>Copyright © Your Company Name</p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/layouts/theme_footer.blade.php ENDPATH**/ ?>