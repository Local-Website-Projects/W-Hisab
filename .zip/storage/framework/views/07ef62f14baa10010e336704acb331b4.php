<?php $__env->startSection('content'); ?>
    <div id="main-wrapper">
        <!--**********************************
            Nav header start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_navHeader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <?php echo $__env->make('layouts.theme-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Reports</a></li>
                    </ol>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Cash Book Report</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('report.cashbook')); ?>" method="post" target="_blank">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Form Date</label>
                                                <input type="date" class="form-control" name="form">
                                            </div>
                                            <div class="col-sm-4 mt-2 mt-sm-0">
                                                <label>To Date</label>
                                                <input type="date" class="form-control" name="to">
                                            </div>
                                            <div class="col-sm-4 mt-4">
                                                <button type="submit" class="btn btn-rounded btn-primary mb-2">Report</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Project Wise Cashbook Report</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('report.project')); ?>" method="post" target="_blank">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-8">
                                                <div class="form-group">
                                                    <label>Select Project*</label>
                                                    <select class="form-control form-control-lg default-select" name="project_id" required>
                                                        <option disabled selected>Select Project</option>
                                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($project->project_id); ?>"><?php echo e($project->project_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 mt-4">
                                                <button type="submit" class="btn btn-rounded btn-primary mb-2">Report</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Supplier Profile Report</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('report.supplier')); ?>" method="post" target="_blank">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-8">
                                                <div class="form-group">
                                                    <label>Select Supplier*</label>
                                                    <select class="form-control form-control-lg default-select" name="supplier_id" required>
                                                        <option disabled selected>Select Supplier</option>
                                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($supplier->supplier_id); ?>"><?php echo e($supplier->supplier_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 mt-4">
                                                <button type="submit" class="btn btn-rounded btn-primary mb-2">Report</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Purchaser Profile Report</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('report.purchaser')); ?>" method="post" target="_blank">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-8">
                                                <div class="form-group">
                                                    <label>Select Purchaser*</label>
                                                    <select class="form-control form-control-lg default-select" name="supplier_id" required>
                                                        <option disabled selected>Select Purchaser</option>
                                                        <?php $__currentLoopData = $purchasers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($purchaser->supplier_id); ?>"><?php echo e($purchaser->supplier_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 mt-4">
                                                <button type="submit" class="btn btn-rounded btn-primary mb-2">Report</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('layouts.theme_footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\W-Hisab\resources\views/reports/index.blade.php ENDPATH**/ ?>